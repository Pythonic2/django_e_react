 # Changelog [<%= appname %>]

As principais alterações neste projeto serão documentadas neste arquivo.

Este formato é baseado em [Mantendo um Changelog](http://keepachangelog.com/en/1.0.0/)
e este projeto é aderente ao [Versionamento Semântico](http://semver.org/spec/v2.0.0.html).

<!--
Adicionado       para novas funcionalidades.
Modificado       para mudanças em funcionalidades existentes.
Obsoleto         para funcionalidades estáveis que foram removidas das próximas versões.
Removido         para funcionalidades removidas desta versão.
Corrigido       para qualquer correção de bug.
Segurança        para incentivar usuários a atualizarem em caso de vulnerabilidades.
-->

## [1.0.0] - dd/mm/yyyy
### Adicionado
 - Build através da imagem padrão BB para projeto maven
