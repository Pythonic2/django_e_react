package br.com.bb.dev.exception;

import br.com.bb.dev.erros.exceptions.BBRuntimeException;
import br.com.bb.dev.erros.model.IncluirNaListaErros;
import java.util.Map;

@IncluirNaListaErros
public class ErrosSistema {
	/* Abaixo temos alguns exemplos de erros, mas voce pode fazer o construtor de acordo com sua necessidade, mas sempre
	usando o construtor da classe pai (super) mais adequado.
	Para mais exemplos acesse a documentação da lib dev-java-erro em https://fontes.intranet.bb.com.br/dev/dev-java-erro
	 */

//	public static final class ExemploErroNegocialSemArgumentos extends BBRuntimeException {
//		public static final String MSG_ERRO = "Sua Mensagem de erro";
//		public static final String COD_ERRO = "001"; // Codigo do erro
//
//		public ExemploErroNegocialSemArgumentos() {
//			super(COD_ERRO, MSG_ERRO);
//		}
//	}
//
//	public static final class ExemploErroNegocialCausadoPorOutraException extends BBRuntimeException {
//		public static final String MSG_ERRO = "Sua Mensagem de erro";
//		public static final String COD_ERRO = "002"; // Codigo do erro
//
//		public ExemploErroNegocialCausadoPorOutraException(Throwable throwable) {
//			super(COD_ERRO, MSG_ERRO, throwable);
//		}
//	}
//
//	public static final class ExemploErroNegocialComVariavelMonitoradaNaFormatacao extends BBRuntimeException {
//		public static final String MSG_ERRO = "Mensagem de erro com formatacao para o texto : %s";
//		public static final String COD_ERRO = "003"; // Codigo do erro
//
//		public ExemploErroNegocialComVariavelMonitoradaNaFormatacao(String texto) {
//			super(COD_ERRO, MSG_ERRO);
//			this.put("TEXTO", texto);
//		}
//	}
//
//	public static final class ExemploErroNegocialComVariavelMonitoradaOpcional extends BBRuntimeException {
//		public static final String MSG_ERRO = "Mensagem de erro de exemplo";
//		public static final String COD_ERRO = "004"; // Codigo do erro
//
//		public ExemploErroNegocialComVariavelMonitoradaOpcional(Map<String, String> variaveisAdicionais) {
//			super(COD_ERRO, MSG_ERRO);
//			this.putAll(variaveisAdicionais);
//		}
//	}
}

